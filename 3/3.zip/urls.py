from views import index_view, elements_view

routes = {
    '/': index_view,
    '/elements/': elements_view,
}

